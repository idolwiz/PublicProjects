## Sales Data Analysis

### This data project has been used as a take-home assignment in the recruitment process for the data science positions at 23andMe Assignment.

#####  The information gathered for this assignment is from StrataScratch

## Please answer the questions below based on the data provided:

 <p> &#x2022; Plot daily sales for all 50 weeks. </p>
  <p> &#x2022; It looks like there has been a sudden change in daily sales. What date did it occur?</p>
  <p>&#x2022;  Is the change in daily sales at the date you selected statistically significant? If so, what is the p-value?</p>
   <p> &#x2022; Does the data suggest that the change in daily sales is due to a shift in the proportion of male-vs-female customers? Please use plots to support your answer (a rigorous statistical analysis is not necessary).</p>
   <p>&#x2022; What is the percentage of sales in each daypart over all 50 weeks? 
  Assume a given day is divided into four dayparts:</p>
      <p>night (12:00AM - 6:00AM), 
       morning (6:00AM - 12:00PM),
       afternoon (12:00PM - 6:00PM),
       evening (6:00PM - 12:00AM).</p>
  



```python
#Importing packages
import matplotlib as mpl
import matplotlib.pyplot as plt 
%matplotlib inline
import numpy as np
import seaborn as sns
import pandas as pd
import os
import statsmodels.api as sm
import glob
# assign a constant figure size and use it in plotting to make plots larger
FIG_SIZE = (10,10)
```


```python
# get all filenames under the data directory 
f = [pd.read_csv(filename) for filename in glob.glob('*.csv')]

# check the list size to understand how many files will be read
# should be equal to 50
print(len(f))

#  create the dataset using all files under the data directory
df = pd.concat(f, axis=0)
df.head()
```

    50





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sale_time</th>
      <th>purchaser_gender</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2013-01-07 02:14:07</td>
      <td>female</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2013-01-07 02:57:53</td>
      <td>male</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2013-01-07 02:59:49</td>
      <td>female</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2013-01-07 03:02:53</td>
      <td>male</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2013-01-07 03:27:36</td>
      <td>female</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Info and description of the combined dataset
df.info()
df.describe()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 204329 entries, 0 to 4974
    Data columns (total 2 columns):
     #   Column            Non-Null Count   Dtype 
    ---  ------            --------------   ----- 
     0   sale_time         204329 non-null  object
     1   purchaser_gender  204329 non-null  object
    dtypes: object(2)
    memory usage: 4.7+ MB





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sale_time</th>
      <th>purchaser_gender</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>204329</td>
      <td>204329</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>203411</td>
      <td>2</td>
    </tr>
    <tr>
      <th>top</th>
      <td>2013-06-12 12:26:28</td>
      <td>female</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>3</td>
      <td>107740</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Checking for any null values
df.isnull().sum()
```




    sale_time           0
    purchaser_gender    0
    dtype: int64




```python
# Making sure the sales time data is actually in date time format
sales_day = pd.to_datetime(df['sale_time'])
```

<p>Create a new dataframe called daily sales, the dataframe is grouped by the sales_day column.</p>
<p>The sales_day column, which is currently the index. uses dt.floor and gets the 'day' in the datetime</p>
<p>Using size() to get the count of sales within that day. and reset_index so sales_day is no longer the index</p>


```python
daily_sales = sales_day.groupby(sales_day.dt.floor('d')).size().reset_index(name = "Count_of_Sales")
daily_sales.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sale_time</th>
      <th>Count_of_Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2012-10-01</td>
      <td>514</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2012-10-02</td>
      <td>482</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2012-10-03</td>
      <td>499</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2012-10-04</td>
      <td>546</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2012-10-05</td>
      <td>476</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Renaming sale_time to sale_day
daily_sales.rename(columns={'sale_time':'sale_day'}, inplace =True)
daily_sales.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sale_day</th>
      <th>Count_of_Sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2012-10-01</td>
      <td>514</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2012-10-02</td>
      <td>482</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2012-10-03</td>
      <td>499</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2012-10-04</td>
      <td>546</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2012-10-05</td>
      <td>476</td>
    </tr>
  </tbody>
</table>
</div>



## Question 1 : <p></p> Plot daily sales for all 50 weeks. 


```python
# Make sales_day the index to use it in plotting
daily_sales.index = daily_sales['sale_day']
daily_sales.drop(columns=['sale_day'],inplace = True)
#Plot Showing Daily sales for every week
daily_sales.plot(figsize=FIG_SIZE, title = "Daily sales over 50 weeks")
plt.show()
```


    
![png](output_10_0.png)
    


## Question 2:  <p></p>It looks like there has been a sudden change in daily sales. What date did it occur?

<p>At first glance it the largest change happens in April or May, but we need to dive deeper to see the actual date</p>


```python
# Creating a comparison between sales for the given days, 
# which checks the difference between the day and the previous day
daily_sales['previous_day'] = [None] + daily_sales['Count_of_Sales'].to_list()[:-1]
daily_sales['difference'] = daily_sales['Count_of_Sales'] - daily_sales['previous_day']
daily_sales.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Count_of_Sales</th>
      <th>previous_day</th>
      <th>difference</th>
    </tr>
    <tr>
      <th>sale_day</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2012-10-01</th>
      <td>514</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2012-10-02</th>
      <td>482</td>
      <td>514.0</td>
      <td>-32.0</td>
    </tr>
    <tr>
      <th>2012-10-03</th>
      <td>499</td>
      <td>482.0</td>
      <td>17.0</td>
    </tr>
    <tr>
      <th>2012-10-04</th>
      <td>546</td>
      <td>499.0</td>
      <td>47.0</td>
    </tr>
    <tr>
      <th>2012-10-05</th>
      <td>476</td>
      <td>546.0</td>
      <td>-70.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Getting the index of the largest change to answer what date did it occur
# Then returning the record of the largest difference 
print(daily_sales['difference'].idxmax())
daily_sales[daily_sales.index == '2013-04-29']
```

    2013-04-29 00:00:00





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Count_of_Sales</th>
      <th>previous_day</th>
      <th>difference</th>
    </tr>
    <tr>
      <th>sale_day</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2013-04-29</th>
      <td>732</td>
      <td>458.0</td>
      <td>274.0</td>
    </tr>
  </tbody>
</table>
</div>



## Question 3: <p></p> Is the change in daily sales at the date you selected statistically significant? If so, what is the p-value?


```python
# Drop all NaN values for the test
daily_sales.dropna(inplace=True)
```


```python
from scipy import stats

# Performing a one-sample t-test
t_statistic, p_value = stats.ttest_1samp(daily_sales['Count_of_Sales'], 732)

# Displaying the results
print("T-statistic:", t_statistic)
print("P-value:", p_value)
```

    T-statistic: -26.273266340051002
    P-value: 1.3019593251472396e-84


<p>The P-value is 1.3019593251472396e-84, if going by traditional convention the number is below 0.05 which would make it statistically significant. So the date of 2013-04-29 was a major sales date </p>

## Question4: <p></p> Does the data suggest that the change in daily sales is due to a shift in the proportion of male-vs-female customers? Please use plots to support your answer (a rigorous statistical analysis is not necessary).


```python
# Set sale_time info to a datetime, setting it to the floor of day and renaming to sales_day
df['sale_day'] = pd.to_datetime(df['sale_time']).dt.floor('d')
# Group count of sales to each gender for each day
gender_df = df.groupby(['sale_day','purchaser_gender']).size().reset_index(name='count_of_sales')
gender_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sale_day</th>
      <th>purchaser_gender</th>
      <th>count_of_sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2012-10-01</td>
      <td>female</td>
      <td>413</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2012-10-01</td>
      <td>male</td>
      <td>101</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2012-10-02</td>
      <td>female</td>
      <td>379</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2012-10-02</td>
      <td>male</td>
      <td>103</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2012-10-03</td>
      <td>female</td>
      <td>386</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>695</th>
      <td>2013-09-13</td>
      <td>male</td>
      <td>537</td>
    </tr>
    <tr>
      <th>696</th>
      <td>2013-09-14</td>
      <td>female</td>
      <td>193</td>
    </tr>
    <tr>
      <th>697</th>
      <td>2013-09-14</td>
      <td>male</td>
      <td>462</td>
    </tr>
    <tr>
      <th>698</th>
      <td>2013-09-15</td>
      <td>female</td>
      <td>230</td>
    </tr>
    <tr>
      <th>699</th>
      <td>2013-09-15</td>
      <td>male</td>
      <td>522</td>
    </tr>
  </tbody>
</table>
<p>700 rows × 3 columns</p>
</div>




```python
# Calculating male and female sales separately for each unique sales day
df_2 = pd.DataFrame(gender_df['sale_day'].unique(),columns=['sale_day'])
# Creating a column for female and male sales, then reset the index so we still use integer indexing
df_2['female_sales'] = pd.Series(gender_df[gender_df['purchaser_gender'] == 'female']['count_of_sales']).reset_index(drop=True)
df_2['male_sales'] = pd.Series(gender_df[gender_df['purchaser_gender'] == 'male']['count_of_sales']).reset_index(drop=True)
df_2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sale_day</th>
      <th>female_sales</th>
      <th>male_sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2012-10-01</td>
      <td>413</td>
      <td>101</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2012-10-02</td>
      <td>379</td>
      <td>103</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2012-10-03</td>
      <td>386</td>
      <td>113</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2012-10-04</td>
      <td>432</td>
      <td>114</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2012-10-05</td>
      <td>368</td>
      <td>108</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Calculate the gender ratio of the sales
df_2['ratio'] = df_2['male_sales']/df_2['female_sales']

# Plotting the ratio over 50 weeks on the total sales chart to observe possible correlation
plot_df=df_2.copy()
plot_df['total_sales'] = plot_df['male_sales'] + plot_df['female_sales']
plot_df.drop(columns=['female_sales','male_sales'],inplace=True)
plot_df.index = plot_df['sale_day']
plot_df.drop(columns=['sale_day'],inplace=True)
plot_df.plot(secondary_y = ['ratio'],figsize=FIG_SIZE, title= "Male/Female Gender Ratio to sales amount over  50 weeks")
plt.show()
```


    
![png](output_22_0.png)
    


<p>Looking at the data in this chart, it shows that while males have increasing bought more over time it does not justify the rapid increase in sales on April 29th or afterwards. There must have been a promotion or some other factor contributing to sales</p>

## Question 5 <p></p> What is the percentage of sales in each daypart over all 50 weeks? 


```python
# Extracting the sale hour to divide sales into parts of the day
df['sale_hour'] = pd.to_datetime(df['sale_time']).dt.ceil('h').dt.hour
```


```python
# Define a function to apply sale hour column to figure out the part of day based on rules above
def day_parter(sale_hour):
    if sale_hour >= 6 and sale_hour < 12:
        return 'morning'
    if sale_hour >= 12 and sale_hour < 18:
        return 'afternoon'
    if sale_hour >= 18 and sale_hour < 24:
        return 'evening'
    if sale_hour >= 0 and sale_hour < 6:
        return 'night'
    
```


```python
# Use the function to create day_part column
df['day_part'] = df['sale_hour'].apply(day_parter)

# dropping unneeded columns
df.drop(columns = ['purchaser_gender', 'sale_hour', 'sale_time'], inplace= True)
```


```python
# Calculating the number of sales by time of day
df_dp = df.groupby(df.day_part).size().reset_index(name='day_part_sales')

# Calculating sales percentage for each time of day
df_dp['sales_percentage'] = (df_dp['day_part_sales']/df_dp['day_part_sales'].sum()) * 100
```


```python
df_dp
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>day_part</th>
      <th>day_part_sales</th>
      <th>sales_percentage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>afternoon</td>
      <td>81159</td>
      <td>39.719766</td>
    </tr>
    <tr>
      <th>1</th>
      <td>evening</td>
      <td>53523</td>
      <td>26.194520</td>
    </tr>
    <tr>
      <th>2</th>
      <td>morning</td>
      <td>56080</td>
      <td>27.445933</td>
    </tr>
    <tr>
      <th>3</th>
      <td>night</td>
      <td>13567</td>
      <td>6.639782</td>
    </tr>
  </tbody>
</table>
</div>



<p> No surprise that that afternoon is the largest percent of sales, generally from 12pm to 6pm people are more productive and active in everything, spending money would be no exception to that</p>


```python

```
